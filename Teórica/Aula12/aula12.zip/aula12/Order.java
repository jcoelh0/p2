
class Order {

   final String prodName;
   final String clientName;
   final int quantity;

   Order(String prod,String client,int quant) {
      prodName = prod;
      clientName = client;
      quantity = quant;
   }
}
